module.exports = {
  parentId: '1197874273948274778', 
  probot_ids: ['282859044593598464'], 
  recipientId: '1152359791117733889', 
  price: 20000
} 